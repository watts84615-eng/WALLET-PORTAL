require('dotenv').config();
const express = require('express'), mongoose = require('mongoose'), cors = require('cors');
const bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken');
const { Schema, model } = mongoose;

const User = model('User', new Schema({
  username: { type: String, required: true, unique: true }, password: String,
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  walletBalance: { type: Number, default: 0, min: 0 }, blocked: { type: Boolean, default: false } }));
const Service = model('Service', new Schema({ name: String, cost: Number, isActive: { type: Boolean, default: true } }));
const Txn = model('Transaction', new Schema({ userId: Schema.Types.ObjectId, amount: Number,
  type: { type: String, enum: ['credit', 'debit'] }, description: String, date: { type: Date, default: Date.now } }));
const Topup = model('Topup', new Schema({ userId: Schema.Types.ObjectId, username: String, amount: Number, utr: String,
  status: { type: String, default: 'pending' }, date: { type: Date, default: Date.now } }));
const Order = model('Order', new Schema({ userId: Schema.Types.ObjectId, username: String, serviceName: String, cost: Number,
  customerName: String, idNumber: String, whatsapp: String, status: { type: String, default: 'processing' },
  refunded: { type: Boolean, default: false }, date: { type: Date, default: Date.now } }));

const app = express(); const origins = (process.env.FRONTEND_ORIGIN || '*').split(',').map(x => x.trim());
app.use(cors({ origin: origins.includes('*') ? true : origins }));
app.use(express.json({ limit: '10kb' }));
// simple brake on password guessing: max 10 login/register tries per IP per 15 minutes
const tries = new Map();
const limit = (req, res, next) => {
  const k = req.ip, now = Date.now(), t = (tries.get(k) || []).filter(x => now - x < 900000);
  if (t.length >= 10) return res.status(429).json({ message: 'Too many tries. Wait 15 minutes.' });
  t.push(now); tries.set(k, t); next();
};
app.set('trust proxy', 1);
const wrap = f => (req, res) => f(req, res).catch(e => res.status(500).json({ message: e.message }));
const sign = u => jwt.sign({ id: u._id, role: u.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
const auth = async (req, res, next) => {
  try {
    const p = jwt.verify((req.headers.authorization || '').replace('Bearer ', ''), process.env.JWT_SECRET);
    const u = await User.findById(p.id); if (!u || u.blocked) throw 0; req.user = u; next();
  } catch { res.status(401).json({ message: 'Please login again' }); }
};
const admin = (req, res, next) => req.user.role === 'admin' ? next() : res.status(403).json({ message: 'Admin only' });
const credit = async (id, amt, why) => { await User.updateOne({ _id: id }, { $inc: { walletBalance: amt } }); await Txn.create({ userId: id, amount: amt, type: 'credit', description: why }); };

app.post('/api/register', limit, wrap(async (req, res) => {
  const { username, password } = req.body;
  if (!/^[a-zA-Z0-9_]{4,20}$/.test(username || '') || (password || '').length < 6) return res.status(400).json({ message: 'Username 4-20 letters/numbers, password min 6' });
  if (await User.findOne({ username })) return res.status(400).json({ message: 'Username already taken' });
  const u = await User.create({ username, password: await bcrypt.hash(password, 10) });
  res.json({ token: sign(u) });
}));
app.post('/api/login', limit, wrap(async (req, res) => {
  const u = await User.findOne({ username: req.body.username });
  if (!u || u.blocked || !(await bcrypt.compare(req.body.password || '', u.password))) return res.status(400).json({ message: 'Wrong username or password' });
  res.json({ token: sign(u) });
}));
app.get('/api/me', auth, wrap(async (req, res) => {
  const u = req.user;
  res.json({ username: u.username, role: u.role, balance: u.walletBalance, services: await Service.find({ isActive: true }),
    ledger: await Txn.find({ userId: u._id }).sort({ date: -1 }).limit(100), orders: await Order.find({ userId: u._id }).sort({ date: -1 }).limit(50),
    topups: await Topup.find({ userId: u._id }).sort({ date: -1 }).limit(20) });
}));
app.post('/api/topup', auth, wrap(async (req, res) => {
  const amount = Number(req.body.amount), utr = String(req.body.utr || '').trim();
  if (!(amount >= 100) || utr.length < 6) return res.status(400).json({ message: 'Minimum Rs 100 and enter UPI reference (UTR)' });
  await Topup.create({ userId: req.user._id, username: req.user.username, amount, utr });
  res.json({ message: 'Request sent. Balance is added after admin checks your payment.' });
}));
app.post('/api/order', auth, wrap(async (req, res) => {
  const { serviceId, customerName, idNumber, whatsapp, consent } = req.body;
  const s = await Service.findOne({ _id: serviceId, isActive: true });
  if (!s) return res.status(404).json({ message: 'Service not found' });
  if (!/^\d{12}$/.test(idNumber || '')) return res.status(400).json({ message: 'Enter exactly 12 digits' });
  if (!(customerName || '').trim()) return res.status(400).json({ message: 'Enter customer name' });
  if (whatsapp && !/^[6-9]\d{9}$/.test(whatsapp)) return res.status(400).json({ message: 'WhatsApp number must be 10 digits' });
  if (!consent) return res.status(400).json({ message: 'Customer consent is required' });
  // atomic: deduct only if balance is enough, so it can never go below zero
  const u = await User.findOneAndUpdate({ _id: req.user._id, walletBalance: { $gte: s.cost } }, { $inc: { walletBalance: -s.cost } }, { new: true });
  if (!u) return res.status(400).json({ message: 'Insufficient balance. Add money to wallet first.' });
  await Txn.create({ userId: u._id, amount: s.cost, type: 'debit', description: `${s.name} - ${customerName}` });
  await Order.create({ userId: u._id, username: u.username, serviceName: s.name, cost: s.cost, customerName, idNumber, whatsapp: whatsapp || '' });
  res.json({ message: 'YOUR CARD IS PROCESSING', balance: u.walletBalance });
}));

const A = [auth, admin];
app.get('/api/admin/data', A, wrap(async (req, res) => res.json({
  users: await User.find({ role: 'user' }).select('-password'), topups: await Topup.find().sort({ date: -1 }).limit(100),
  orders: await Order.find().sort({ date: -1 }).limit(200), services: await Service.find() })));
app.post('/api/admin/topup/:id', A, wrap(async (req, res) => {
  const status = req.body.approve ? 'approved' : 'rejected';
  const t = await Topup.findOneAndUpdate({ _id: req.params.id, status: 'pending' }, { status });
  if (!t) return res.status(400).json({ message: 'Already handled' });
  if (req.body.approve) await credit(t.userId, t.amount, `Wallet top-up (UTR ${t.utr})`);
  res.json({ ok: true });
}));
app.post('/api/admin/wallet', A, wrap(async (req, res) => {
  const amt = Number(req.body.amount); if (!amt) return res.status(400).json({ message: 'Enter amount' });
  if (amt > 0) await credit(req.body.userId, amt, 'Added by admin');
  else {
    const u = await User.findOneAndUpdate({ _id: req.body.userId, walletBalance: { $gte: -amt } }, { $inc: { walletBalance: amt } });
    if (!u) return res.status(400).json({ message: 'Not enough balance' });
    await Txn.create({ userId: u._id, amount: -amt, type: 'debit', description: 'Deducted by admin' });
  }
  res.json({ ok: true });
}));
app.post('/api/admin/block', A, wrap(async (req, res) => { await User.updateOne({ _id: req.body.userId }, { blocked: !!req.body.blocked }); res.json({ ok: true }); }));
app.post('/api/admin/service', A, wrap(async (req, res) => {
  const { id, name, cost, isActive } = req.body;
  if (id) await Service.updateOne({ _id: id }, { cost: Number(cost), isActive }); else await Service.create({ name, cost: Number(cost) });
  res.json({ ok: true });
}));
app.post('/api/admin/order/:id', A, wrap(async (req, res) => {
  const o = await Order.findById(req.params.id); if (!o) return res.status(404).json({ message: 'Not found' });
  const status = req.body.status; o.status = status;
  if (status === 'rejected' && !o.refunded) { // refund once
    const r = await Order.updateOne({ _id: o._id, refunded: false }, { refunded: true });
    if (r.modifiedCount) await credit(o.userId, o.cost, `Refund - ${o.serviceName} (${o.customerName})`);
  }
  await Order.updateOne({ _id: o._id }, { status }); res.json({ ok: true });
}));

mongoose.connect(process.env.MONGO_URI).then(async () => {
  if (!(await User.findOne({ role: 'admin' }))) await User.create({ username: process.env.ADMIN_USERNAME || 'admin', role: 'admin', password: await bcrypt.hash(process.env.ADMIN_PASSWORD || 'admin12345', 10) });
  if (!(await Service.countDocuments())) await Service.create({ name: 'Farmer Card', cost: 20 });
  app.listen(process.env.PORT || 5000, () => console.log('Server running'));
}).catch(e => console.error('MongoDB error:', e.message));

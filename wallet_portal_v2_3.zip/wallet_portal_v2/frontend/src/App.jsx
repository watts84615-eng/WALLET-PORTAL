import React, { useState, useEffect, useCallback } from 'react';
const API = import.meta.env.VITE_API || 'http://localhost:5000';
const inp = 'w-full border p-2 rounded';
const btn = 'bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded';

export default function App() {
  const [token, setToken] = useState(localStorage.getItem('tk') || '');
  const [me, setMe] = useState(null);
  const [tab, setTab] = useState('user');
  const call = useCallback(async (path, body) => {
    const r = await fetch(API + path, { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: body && JSON.stringify(body) });
    const d = await r.json();
    if (r.status === 401) { localStorage.removeItem('tk'); setToken(''); }
    if (!r.ok) throw new Error(d.message || 'Error');
    return d;
  }, [token]);
  const load = useCallback(() => call('/api/me').then(setMe).catch(() => {}), [call]);
  useEffect(() => { if (token) load(); }, [token, load]);

  if (!token) return <Login onToken={t => { localStorage.setItem('tk', t); setToken(t); }} />;
  if (!me) return <p className="p-6">Loading...</p>;
  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-blue-600 text-white p-4 flex flex-wrap gap-3 justify-between items-center">
        <b>Wallet Portal - {me.username}</b>
        <div className="flex gap-3 items-center">
          {me.role === 'admin' && <button className="bg-amber-500 px-3 py-1 rounded text-sm font-bold" onClick={() => setTab(tab === 'user' ? 'admin' : 'user')}>{tab === 'user' ? 'Admin' : 'User'} view</button>}
          <span className="bg-blue-700 px-3 py-2 rounded font-semibold">Wallet: ₹{me.balance}</span>
          <button className="underline text-sm" onClick={() => { localStorage.removeItem('tk'); setToken(''); setMe(null); }}>Logout</button>
        </div>
      </nav>
      <div className="p-4 max-w-5xl mx-auto">
        {tab === 'admin' && me.role === 'admin' ? <Admin call={call} /> : <UserView me={me} call={call} reload={load} />}
      </div>
    </div>
  );
}

function Login({ onToken }) {
  const [mode, setMode] = useState('login'); const [f, setF] = useState({ username: '', password: '' }); const [err, setErr] = useState('');
  const go = async () => {
    const r = await fetch(API + '/api/' + mode, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(f) });
    const d = await r.json(); r.ok ? onToken(d.token) : setErr(d.message);
  };
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="bg-white p-6 rounded-xl shadow w-full max-w-sm space-y-3">
        <h1 className="text-xl font-bold">{mode === 'login' ? 'Login' : 'Create account'}</h1>
        <input className={inp} placeholder="Username" value={f.username} onChange={e => setF({ ...f, username: e.target.value })} />
        <input className={inp} type="password" placeholder="Password" value={f.password} onChange={e => setF({ ...f, password: e.target.value })} />
        {err && <p className="text-red-600 text-sm">{err}</p>}
        <button className={btn + ' w-full'} onClick={go}>{mode === 'login' ? 'Login' : 'Register'}</button>
        <button className="text-sm underline" onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setErr(''); }}>{mode === 'login' ? 'New user? Register' : 'Have an account? Login'}</button>
      </div>
    </div>
  );
}

function UserView({ me, call, reload }) {
  const [amount, setAmount] = useState(100); const [utr, setUtr] = useState(''); const [msg, setMsg] = useState('');
  const run = async (fn) => { try { setMsg((await fn()).message); reload(); } catch (e) { setMsg(e.message); } };
  return (
    <div className="space-y-6">
      {msg && <div className="bg-orange-100 border-l-4 border-orange-500 text-orange-800 p-3 rounded font-bold">{msg}</div>}
      <div className="bg-white p-5 rounded-xl shadow space-y-2">
        <h3 className="font-bold">Add money to wallet (minimum ₹100)</h3>
        <p className="text-sm text-gray-600">Pay by UPI to the shop's UPI ID, then enter the UTR / reference number. Balance is added after admin checks.</p>
        <div className="flex flex-wrap gap-2">
          <input className="border p-2 rounded w-28" type="number" value={amount} onChange={e => setAmount(e.target.value)} />
          <input className="border p-2 rounded flex-1" placeholder="UPI reference (UTR)" value={utr} onChange={e => setUtr(e.target.value)} />
          <button className={btn} onClick={() => run(() => call('/api/topup', { amount, utr }))}>Send request</button>
        </div>
      </div>
      <div className="grid md:grid-cols-2 gap-4">{me.services.map(s => <ServiceBox key={s._id} s={s} run={run} call={call} />)}</div>
      <Table title="My orders" head={['Date', 'Service', 'Customer', 'Status']} rows={me.orders.map(o => [o.date.slice(0, 10), o.serviceName, o.customerName, o.status])} />
      <Table title="Account ledger (ਹਿਸਾਬ-ਕਿਤਾਬ)" head={['Date', 'Description', 'Amount']} rows={me.ledger.map(l => [l.date.slice(0, 10), l.description, (l.type === 'credit' ? '+' : '-') + '₹' + Math.abs(l.amount)])} />
    </div>
  );
}

function ServiceBox({ s, run, call }) {
  const [f, setF] = useState({ idNumber: '', customerName: '', whatsapp: '', consent: false });
  const submit = () => run(async () => { const d = await call('/api/order', { ...f, serviceId: s._id }); setF({ idNumber: '', customerName: '', whatsapp: '', consent: false }); return d; });
  return (
    <div className="bg-white p-5 rounded-xl shadow space-y-3">
      <h3 className="text-xl font-bold text-blue-600">{s.name}</h3>
      <div>
        <label className="text-sm font-semibold">ਆਪਣੇ 12 ਅੰਕ ਇੱਥੇ ਲਿਖੋ (Enter 12-digit number)</label>
        <input className={inp} maxLength={12} inputMode="numeric" placeholder="123456789012" value={f.idNumber} onChange={e => setF({ ...f, idNumber: e.target.value.replace(/\D/g, '') })} />
        <p className="text-sm text-green-700 mt-1">ਜੇ ਤੁਸੀਂ ਆਪਣਾ ਕਾਰਡ WhatsApp ਤੇ ਲੈਣਾ ਚਾਹੁੰਦੇ ਹੋ ਤਾਂ ਆਪਣਾ WhatsApp ਨੰਬਰ ਦਰਜ ਕਰੋ।<br /><span className="text-gray-500">(If you want your card on WhatsApp, enter your WhatsApp number)</span></p>
        <input className={inp + ' mt-1'} maxLength={10} inputMode="numeric" placeholder="WhatsApp number (optional)" value={f.whatsapp} onChange={e => setF({ ...f, whatsapp: e.target.value.replace(/\D/g, '') })} />
      </div>
      <input className={inp} placeholder="ਗ੍ਰਾਹਕ ਦਾ ਨਾਮ (Customer name)" value={f.customerName} onChange={e => setF({ ...f, customerName: e.target.value })} />
      <label className="flex gap-2 text-sm"><input type="checkbox" checked={f.consent} onChange={e => setF({ ...f, consent: e.target.checked })} />Customer has agreed to share these details for this service.</label>
      <div className="flex justify-between items-center"><b className="text-red-500">Charges: ₹{s.cost}</b><button className={btn} onClick={submit}>Pay & Process</button></div>
    </div>
  );
}

function Table({ title, head, rows }) {
  return (
    <div className="bg-white p-5 rounded-xl shadow overflow-x-auto"><h3 className="font-bold mb-2">{title}</h3>
      <table className="w-full text-left text-sm"><thead><tr className="bg-gray-100">{head.map(h => <th key={h} className="p-2">{h}</th>)}</tr></thead>
        <tbody>{rows.map((r, i) => <tr key={i} className="border-b">{r.map((c, j) => <td key={j} className="p-2">{c}</td>)}</tr>)}</tbody></table>
      {!rows.length && <p className="text-gray-400 text-sm p-2">Nothing yet</p>}</div>
  );
}

function Admin({ call }) {
  const [d, setD] = useState(null); const [msg, setMsg] = useState(''); const [ns, setNs] = useState({ name: '', cost: '' });
  const load = useCallback(() => call('/api/admin/data').then(setD), [call]);
  useEffect(() => { load(); }, [load]);
  const act = async (p, b) => { try { await call(p, b); setMsg('Done'); load(); } catch (e) { setMsg(e.message); } };
  if (!d) return <p>Loading...</p>;
  return (
    <div className="space-y-6">
      {msg && <div className="bg-blue-100 p-2 rounded">{msg}</div>}
      <div className="bg-white p-5 rounded-xl shadow"><h3 className="font-bold mb-2">Wallet top-up requests</h3>
        {d.topups.filter(t => t.status === 'pending').map(t => (
          <div key={t._id} className="flex flex-wrap gap-2 items-center border-b py-2 text-sm"><span>{t.username} - ₹{t.amount} - UTR {t.utr}</span>
            <button className="bg-green-600 text-white px-2 rounded" onClick={() => act('/api/admin/topup/' + t._id, { approve: true })}>Approve</button>
            <button className="bg-red-600 text-white px-2 rounded" onClick={() => act('/api/admin/topup/' + t._id, { approve: false })}>Reject</button></div>))}</div>
      <div className="bg-white p-5 rounded-xl shadow overflow-x-auto"><h3 className="font-bold mb-2">Orders</h3>
        <table className="w-full text-sm text-left"><thead><tr className="bg-gray-100"><th className="p-2">By</th><th>Customer</th><th>12-digit</th><th>WhatsApp</th><th>Status</th></tr></thead><tbody>
          {d.orders.map(o => (<tr key={o._id} className="border-b"><td className="p-2">{o.username}</td><td>{o.customerName}</td><td>{o.idNumber}</td><td>{o.whatsapp || '-'}</td>
            <td><select className="border rounded" value={o.status} onChange={e => act('/api/admin/order/' + o._id, { status: e.target.value })}>
              <option value="processing">processing</option><option value="done">done</option><option value="rejected">rejected (refund)</option></select></td></tr>))}</tbody></table></div>
      <div className="bg-white p-5 rounded-xl shadow overflow-x-auto"><h3 className="font-bold mb-2">Users</h3>
        {d.users.map(u => (<UserRow key={u._id} u={u} act={act} />))}</div>
      <div className="bg-white p-5 rounded-xl shadow space-y-2"><h3 className="font-bold">Services and prices</h3>
        {d.services.map(s => (<div key={s._id} className="flex gap-2 items-center"><span className="w-40">{s.name}</span>₹<input className="border w-20 p-1 rounded" type="number" defaultValue={s.cost} onBlur={e => act('/api/admin/service', { id: s._id, cost: e.target.value, isActive: s.isActive })} />
          <label className="text-sm"><input type="checkbox" checked={s.isActive} onChange={e => act('/api/admin/service', { id: s._id, cost: s.cost, isActive: e.target.checked })} /> active</label></div>))}
        <div className="flex gap-2"><input className="border p-1 rounded" placeholder="New service" value={ns.name} onChange={e => setNs({ ...ns, name: e.target.value })} />
          <input className="border p-1 rounded w-24" type="number" placeholder="₹" value={ns.cost} onChange={e => setNs({ ...ns, cost: e.target.value })} />
          <button className={btn} onClick={() => act('/api/admin/service', ns)}>Add</button></div></div>
    </div>
  );
}

function UserRow({ u, act }) {
  const [amt, setAmt] = useState('');
  return (
    <div className="flex flex-wrap gap-2 items-center border-b py-2 text-sm"><span className="w-32">{u.username}</span><b>₹{u.walletBalance}</b>
      <input className="border p-1 rounded w-24" type="number" placeholder="+/- ₹" value={amt} onChange={e => setAmt(e.target.value)} />
      <button className="bg-green-600 text-white px-2 rounded" onClick={() => act('/api/admin/wallet', { userId: u._id, amount: amt })}>Apply</button>
      <button className="bg-gray-700 text-white px-2 rounded" onClick={() => act('/api/admin/block', { userId: u._id, blocked: !u.blocked })}>{u.blocked ? 'Unblock' : 'Block'}</button></div>
  );
}
